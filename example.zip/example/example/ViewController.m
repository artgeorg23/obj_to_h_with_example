//
//  ViewController.m
//  example
//
//  Created by artur on 08.09.14.
//  Copyright (c) 2014 Artur. All rights reserved.
//

#import "ViewController.h"

#import "untitled.h"

#import "untitled1.h"


@interface ViewController ()
{
    GLKMatrix4 modelViewProjectionMatrix;
    GLKMatrix3 normalMatrix;
    float rotation;
    
    GLuint vertexArray1;
    GLuint vertexArray;
    GLuint vertexBuffer;
    GLuint vertexBuffer1;
    
    
}
@property (strong, nonatomic) EAGLContext *context;
@property (strong, nonatomic) GLKBaseEffect *effect;
@property (strong, nonatomic) GLKBaseEffect *effect1;

- (void)setupGL;
- (void)tearDownGL;
@property (strong, nonatomic) GLKTextureInfo *texture;
@end


@implementation ViewController

@synthesize texture = _texture;
@synthesize context = _context;
@synthesize effect = _effect;

@synthesize effect1 = _effect1;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    
    if (!self.context) {
        NSLog(@"Failed to create ES context");
    }
    
    GLKView *view = (GLKView *)self.view;
    view.context = self.context;
    view.drawableDepthFormat = GLKViewDrawableDepthFormat24;
    
    [self setupGL];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    [self tearDownGL];
    
    if ([EAGLContext currentContext] == self.context) {
        [EAGLContext setCurrentContext:nil];
    }
	self.context = nil;
}
- (void)setupGL
{
    [EAGLContext setCurrentContext:self.context];
    
    self.effect = [[GLKBaseEffect alloc] init];
    self.effect1 = [[GLKBaseEffect alloc] init];
    
    self.effect.lightingType = GLKLightingTypePerVertex;
    
    self.effect1.lightingType = GLKLightingTypePerVertex;
    
    //self.effect.colorMaterialEnabled = YES;
    
    // Turn on the first light
    self.effect.light0.enabled = GL_TRUE;
    self.effect.light0.diffuseColor = GLKVector4Make(1.0f, 0.4f, 0.4f, 1.0f);
    self.effect.light0.position = GLKVector4Make(-5.f, -5.f, 10.f, 1.0f);
    self.effect.light0.specularColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    
    // Turn on the second light
    self.effect.light1.enabled = GL_TRUE;
    self.effect.light1.diffuseColor = GLKVector4Make(1.0f, 0.4f, 0.4f, 1.0f);
    self.effect.light1.position = GLKVector4Make(15.f, 15.f, 10.f, 1.0f);
    self.effect.light1.specularColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    
    // Set material
    self.effect.material.diffuseColor = GLKVector4Make(0.f, 0.5f, 1.0f, 1.0f);
    self.effect.material.ambientColor = GLKVector4Make(0.0f, 0.5f, 0.0f, 1.0f);
    self.effect.material.specularColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    self.effect.material.shininess = 20.0f;
    self.effect.material.emissiveColor = GLKVector4Make(0.2f, 0.f, 0.2f, 1.0f);
    
    
    // Turn on the first light
    self.effect1.light0.enabled = GL_TRUE;
    self.effect1.light0.diffuseColor = GLKVector4Make(1.0f, 0.4f, 0.4f, 1.0f);
    self.effect1.light0.position = GLKVector4Make(-5.f, -5.f, 10.f, 1.0f);
    self.effect1.light0.specularColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    
    // Turn on the second light
    self.effect1.light1.enabled = GL_TRUE;
    self.effect1.light1.diffuseColor = GLKVector4Make(1.0f, 0.4f, 0.4f, 1.0f);
    self.effect1.light1.position = GLKVector4Make(15.f, 15.f, 10.f, 1.0f);
    self.effect1.light1.specularColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    
    // Set material
    self.effect1.material.diffuseColor = GLKVector4Make(0.f, 0.5f, 1.0f, 1.0f);
    self.effect1.material.ambientColor = GLKVector4Make(0.0f, 0.5f, 0.0f, 1.0f);
    self.effect1.material.specularColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    self.effect1.material.shininess = 20.0f;
    self.effect1.material.emissiveColor = GLKVector4Make(0.2f, 0.f, 0.2f, 1.0f);
    
    glEnable(GL_DEPTH_TEST);
    
    glGenVertexArraysOES(1, &vertexArray);
    glBindVertexArrayOES(vertexArray);
    
    glGenBuffers(1, &vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(MeshVertexData), MeshVertexData, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(vertexDataTextured), 0);
    glEnableVertexAttribArray(GLKVertexAttribNormal);
    glVertexAttribPointer(GLKVertexAttribNormal, 3, GL_FLOAT, GL_FALSE,  sizeof(vertexDataTextured), (char *)12);
    glEnableVertexAttribArray(GLKVertexAttribTexCoord0);
    glVertexAttribPointer(GLKVertexAttribTexCoord0, 2, GL_FLOAT, GL_FALSE, sizeof(vertexDataTextured), (char *)24);
    
    
    glActiveTexture(GL_TEXTURE0);
    NSString *path = [[NSBundle mainBundle] pathForResource:@"1" ofType:@"png"];
    
    NSError *error;
    NSDictionary *options = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES]
                                                        forKey:GLKTextureLoaderOriginBottomLeft];
    
    
    self.texture = [GLKTextureLoader textureWithContentsOfFile:path
                                                       options:options error:&error];
    if (self.texture == nil)
        NSLog(@"Error loading texture: %@", [error localizedDescription]);
    
    
    GLKEffectPropertyTexture *tex = [[GLKEffectPropertyTexture alloc] init];
    tex.enabled = YES;
    tex.envMode = GLKTextureEnvModeDecal;
    tex.name = self.texture.name;
    
    self.effect1.texture2d0.name = tex.name;
    
    glBindVertexArrayOES(0);
    
    
    
    
    
    
    
    
    
    
    
    
    
}

- (void)tearDownGL
{
    [EAGLContext setCurrentContext:self.context];
    
    
    
    glDeleteBuffers(1, &vertexBuffer);
    glDeleteBuffers(1, &vertexBuffer);
    glDeleteVertexArraysOES(1, &vertexArray);
    glDeleteVertexArraysOES(1, &vertexArray);
    
    
    self.effect = nil;
    
    self.effect1 = nil;
    
}

#pragma mark - GLKView and GLKViewController delegate methods

- (void)update
{
    float aspect = fabsf(self.view.bounds.size.width / self.view.bounds.size.height);
    GLKMatrix4 projectionMatrix = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(65.0f), aspect, 0.1f, 100.0f);
    
    self.effect.transform.projectionMatrix = projectionMatrix;
    
    GLKMatrix4 modelViewMatrix = GLKMatrix4MakeTranslation(0.0f, 0.0f, -7.5f);
    modelViewMatrix = GLKMatrix4Rotate(modelViewMatrix, rotation, 1.0f, 1.0f, 1.0f);
    
    self.effect.transform.modelviewMatrix = modelViewMatrix;
    
    
    rotation += self.timeSinceLastUpdate * 0.5f;
    
    GLKMatrix4 projectionMatrix1 = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(65.0f), aspect, 0.1f, 100.0f);
    self.effect1.transform.projectionMatrix = projectionMatrix1;
    
    GLKMatrix4 modelViewMatrix1 = GLKMatrix4MakeTranslation(0.0f, 1.0f, -3.5f);
    modelViewMatrix1 = GLKMatrix4Rotate(modelViewMatrix1, rotation, 1.0f, 1.0f, 1.0f);
    
    modelViewMatrix1 = GLKMatrix4Multiply(modelViewMatrix1, modelViewMatrix);
    
    self.effect1.transform.modelviewMatrix = modelViewMatrix1;
    
    
    rotation += self.timeSinceLastUpdate * 1.5f;
    
    
}

- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect
{
    glClearColor(0.65f, 0.65f, 0.65f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    
    [self createmonkey];
    
    glBindVertexArrayOES(1);
    
    // Render the object with GLKit
    [self.effect prepareToDraw];
    
    glDrawArrays(GL_TRIANGLES, 0, sizeof(MeshVertexData) / sizeof(vertexData));
    
    
    [self createtorus];
    
    // [self createmonkey];
    
    glBindVertexArrayOES(1);
    [self.effect1 prepareToDraw];
    
    
    
    glDrawArrays(GL_TRIANGLES, 0, sizeof(MeshVertexDataTextured) / sizeof(vertexDataTextured));
    
    
    // glDrawArrays(GL_TRIANGLES, 0, sizeof(MeshVertexData) / sizeof(vertexData));
    
    
    
    
    
    
}




-(void)createmonkey
{
    
    
    
    
    
    
    
    glDeleteBuffers(1, &vertexBuffer);
    glDeleteVertexArraysOES(1, &vertexArray);
    
    glBindVertexArrayOES(0);
    
    glEnable(GL_DEPTH_TEST);
    
    
    
    
    glGenVertexArraysOES(1, &vertexArray);
    glBindVertexArrayOES(1);
    
    glGenBuffers(1, &vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(MeshVertexData), MeshVertexData, GL_STATIC_DRAW);
    
    
    
    
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(vertexData), 0);
    glEnableVertexAttribArray(GLKVertexAttribNormal);
    glVertexAttribPointer(GLKVertexAttribNormal, 3, GL_FLOAT, GL_FALSE,  6 * sizeof(GLfloat), (char *)12);
    
    
    glBindVertexArrayOES(0);
    
    
    
    
    
}

-(void)createtorus
{
    glDeleteBuffers(1, &vertexBuffer);
    glDeleteVertexArraysOES(1, &vertexArray);
    
    glBindVertexArrayOES(0);
    
    glEnable(GL_DEPTH_TEST);
    
    
    
    
    glGenVertexArraysOES(1, &vertexArray);
    glBindVertexArrayOES(1);
    
    glGenBuffers(1, &vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(MeshVertexDataTextured), MeshVertexDataTextured, GL_STATIC_DRAW);
    
    
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(vertexDataTextured), 0);
    glEnableVertexAttribArray(GLKVertexAttribNormal);
    glVertexAttribPointer(GLKVertexAttribNormal, 3, GL_FLOAT, GL_FALSE,  sizeof(vertexDataTextured), (char *)12);
    glEnableVertexAttribArray(GLKVertexAttribTexCoord0);
    glVertexAttribPointer(GLKVertexAttribTexCoord0, 2, GL_FLOAT, GL_FALSE, sizeof(vertexDataTextured), (char *)24);
    
    
    glActiveTexture(GL_TEXTURE0);

    
    
    glBindVertexArrayOES(0);
    
    
    
}







@end
