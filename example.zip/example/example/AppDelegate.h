//
//  AppDelegate.h
//  example
//
//  Created by artur on 08.09.14.
//  Copyright (c) 2014 Artur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
